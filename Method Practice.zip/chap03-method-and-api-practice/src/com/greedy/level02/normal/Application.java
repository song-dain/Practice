package com.greedy.level02.normal;

public class Application {

	public static void main(String[] args) {

		System.out.println(RandomMaker.randomNumber(-35, 35));
		
		
		RandomMaker random = new RandomMaker();
		
		System.out.println(random.randomNumber2(-35, 30));
		
		System.out.println(random.randomNumber3(-35, 30));
		
		
		System.out.println(random.rockPaperScissors());
		
		System.out.println(random.rockPaperScissors2());
		
		
		System.out.println(random.birthdaygift());
		System.out.println(random.birthdaygift2());
		

	}

}
