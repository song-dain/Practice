package com.greedy.level02.normal;

import java.util.Random;

public class RandomMaker {
	
	Random random = new Random();
	
	public static int randomNumber(int min, int max) {
		int random1 = (int) (Math.random()*(max - min + 1)) + min;
		return random1;
	}
	
	public int randomNumber2(int min, int max) {
	
		int random1 = random.nextInt(71) -35;
		return random1;
	}
	
	public int randomNumber3(int min, int max) {
		int random1 = (int) (Math.random()*(max - min + 1)) + min;
		return random1;
	}
	
	public String rockPaperScissors() {
		int random1 = random.nextInt(3);
		return random1 == 0 ? "scissors" : random1 == 1 ? "rock" : "paper";
	}
	
	public String rockPaperScissors2() {
		int random1 = (int) (Math.random() * 3);
		return random1 == 0 ? "scissors" : random1 == 1 ? "rock" : "paper";
	}
	
	public String tossCoin() {
		int random1 = (int) (Math.random() * 2);
		return random1 == 0 ? "front" : "back";
	}
	
	public String tossCoin2() {
		int random1 = random.nextInt(2);
		return random1 == 0 ? "front" : "back";
	}
	
	public String birthdaygift() {
		int random1 = (int)Math.random() * 3;
		return random1 == 0 ? "ipad" : random1 == 1 ? "airpods" : "none";
	}
	
	public String birthdaygift2() {
		int random1 = random.nextInt(3);
		return random1 == 0 ? "ipad" : random1 == 1 ? "airpods" : "none";
	}
	
	
	
	
}
