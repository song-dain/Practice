package com.greedy.level01.basic;

public class Application {

	public static void main(String[] args) {
		
		Calculator calc = new Calculator();
		
		calc.checkMethod();
		
		int summt = calc.sum1to10();
		System.out.println(summt);
		
		calc.checkMaxNumber(10, 20);
		
		int plusmt = calc.sumTwoNumber(10, 20);
		System.out.println(plusmt);
		
		int minusmt = calc.minusTwoNumber(10, 5);
		System.out.println(minusmt);


		
	}
		

}
