package com.greedy.level01.basic;

public class Calculator {
	
	public void checkMethod() {
		System.out.println("check method");
	}
	
	public int sum1to10() {
		return 1 + 2 + 3 + 4 + 5 + 6 + 7 + 8 + 9 + 10;
	}
	
	public void checkMaxNumber(int a, int b) {
		System.out.println(Math.max(a, b));
	}
	
	public int sumTwoNumber(int a, int b) {
		return a + b;
	}

	public int minusTwoNumber(int a, int b) {
		return a - b;
	}

}
