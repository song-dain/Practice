package com.greedy.practice;

import java.util.Random;

public class Practice2 {

	public static void main(String[] args) {
		
		Random random = new Random();
		
		int random1 = random.nextInt(15) + 15;
		System.out.println(random1);
		
		System.out.println(random.nextInt(15) + 15);
		
		int random2 = (int) (Math.random() * 15) + 15;
		System.out.println(random2);
		
		System.out.println((int) (Math.random() * 15) + 15);

	}

}
