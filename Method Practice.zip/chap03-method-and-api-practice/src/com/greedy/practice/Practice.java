package com.greedy.practice;

public class Practice {

	public static void main(String[] args) {
		
		Practice pre = new Practice();
		pre.argumentPractice1(27, "dain");
		
		System.out.println(Math.abs(-7));
		System.out.println(Math.max(10, 20));
		System.out.println(Math.min(20, 30));
		System.out.println(Math.PI);
		System.out.println(Math.random());
		
		int random1 = (int) (Math.random()* 15) + 15;
		System.out.println(random1);
		

	}
	
	public void argumentPractice1 (int age, String name) {
		
		System.out.println("name? " + name + ", age? " + age);
	}

}
