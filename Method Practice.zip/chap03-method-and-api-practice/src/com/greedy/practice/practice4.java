package com.greedy.practice;

import java.util.Scanner;

public class practice4 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner (System.in);
		
		/* System.out.println(sc.nextInt());
		sc.nextLine();
		System.out.println(sc.nextLine());
		
		System.out.println(sc.nextLine().charAt(2)); */
		
		System.out.println(sc.next());
		sc.nextLine();
		System.out.println(sc.nextLine());

	}

}
