package com.greedy.practice;

import java.util.Scanner;

public class Practice3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("age? ");
		System.out.println(sc.nextInt());
		
		System.out.print("name? ");
		System.out.println(sc.nextLine());
		
		System.out.print("gender? ");
		System.out.println(sc.nextLine().charAt(0));
		
		System.out.print("true or false? ");
		System.out.println(sc.nextBoolean());
		
		System.out.println("height? ");
		System.out.println(sc.nextDouble());
		

	}

}
