package com.greedy.section01.conditional.level01.basic;

import java.util.Scanner;

  public class Basic {
	
	public void basic1() {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("정수를 하나 입력하세요. : ");
		int num = sc.nextInt();
		
		if(num > 0) {
			System.out.println("양수다.");
		} else {
			System.out.println("양수가 아니다.");
		}
	}

	
	public void basic2() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("정수를 하나 입력하세요. : ");
		int num = sc.nextInt();
		
		if(num % 2 == 0) {
			System.out.println("짝수다");
		} else {
			System.out.println("홀수다.");
		}
	}
}

