package com.example.recycleviewpractice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.recycleviewpractice.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    val binding by lazy { ActivityMainBinding.inflate(layoutInflater) }

    private val todos = listOf(
        Todo("homework complete #1", false),
        Todo("homework complete #2", false),
        Todo("homework complete #3", false),
        Todo("homework complete #4", false),
        Todo("homework complete #5", false),
        Todo("homework complete #6", false),
        Todo("homework complete #7", false),
        Todo("homework complete #8", false),
        Todo("homework complete #9", false),
        Todo("homework complete #10", false),
        Todo("homework complete #11", false),
        Todo("homework complete #12", false),
        Todo("homework complete #13", false),
        Todo("homework complete #14", false),
        Todo("homework complete #15", false),
        Todo("homework complete #16", false),
        Todo("homework complete #17", false),
        Todo("homework complete #18", false),
        Todo("homework complete #19", false),
        Todo("homework complete #20", false)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        initalizeView()
    }

    private fun initalizeView() {
        binding.todoList.layoutManager = LinearLayoutManager(this)
        binding.todoList.adapter = TodoAdapter(todos)
    }
}