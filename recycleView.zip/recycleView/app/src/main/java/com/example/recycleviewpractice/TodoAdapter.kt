package com.example.recycleviewpractice

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.recycleviewpractice.databinding.ActivityMainBinding
import com.example.recycleviewpractice.databinding.ItemTodoBinding

class TodoAdapter(private val todos:List<Todo>) : RecyclerView.Adapter<TodoAdapter.TodoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        val binding = ItemTodoBinding.inflate(LayoutInflater.from(parent.context),
            parent,
            false)
        return TodoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        holder.bind(todos[position])
        holder.binding.completeCheckBox.setOnCheckedChangeListener { buttonView, isChecked ->
            todos[position].completed = isChecked
        }
    }

    override fun getItemCount(): Int = todos.size

    class TodoViewHolder(val binding: ItemTodoBinding) :
        RecyclerView.ViewHolder(binding.root) {

            fun bind(todo: Todo) {
                binding.todoTitle.text = todo.title
                binding.completeCheckBox.isChecked = todo.completed
            }
    }
}
