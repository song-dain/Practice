package com.example.recycleviewpractice

data class Todo(val title: String, var completed: Boolean)